#include <iostream>
#include <gtest/gtest.h>
#include <stack>
#include <string>

using namespace std;

bool IsOperand(char a)
{
    if(a >= '0' && a <= '9'){ return true;}
    if(a >= 'a' && a <= 'z'){ return true;}
    if(a >= 'A' && a <= 'Z') {return true;}
    return false;
}

bool IsOperator(char a)
{
    if(a == '*' || a == '/' || a == '+' || a == '-')
     { 
       return true;
     }
    else {
      return false;
    }
}

int ranking(char a)
{
    int ranking;
    switch(a)
    {
    case '*':
    case '/':
        ranking = 2;
        break;
    case '+':
    case '-':
        ranking = 1;
        break;
    }
    return ranking;
}

bool priority(char a, char b)
{
    int elementone =ranking(a);
    int elementtwo= ranking(b);
    if(elementone >= elementtwo){ 
      return true;
      
    }
    
    return false;
}

string infix2postfix(string infix) {
  // TODO insert your code here
  stack<char> s;
  string postfix="";
  
   for(int i = 0; i < infix.length(); i++)
        if(infix[i] == '(')
        {
            s.push(infix[i]);
        }
        else if(infix[i] == ')')
        {
            while(!s.empty() && s.top() != '(')
            {
                postfix += s.top();
                s.pop();
            }
            s.pop();
        }
        else if(IsOperand(infix[i]))
        {
            postfix += infix[i];
        }
        else if(IsOperator(infix[i]))
        {
            while(!s.empty()&& !priority(infix[i], s.top()))
            {
                postfix+= s.top();
                s.pop();
            }
            s.push(infix[i]);
        }
    while(!s.empty())
    {
        postfix+= s.top();
        s.pop();
    }
  
  
  return postfix;
}

int main() {
  EXPECT_STREQ(infix2postfix("2+3").c_str(), "23+");
  EXPECT_STREQ(infix2postfix("a*b").c_str(), "ab*");
  EXPECT_STREQ(infix2postfix("2+3*5").c_str(), "235*+");
  EXPECT_STREQ(infix2postfix("A+B*C+D").c_str(), "ABC*+D+");
  EXPECT_STREQ(infix2postfix("(A+B)*C-(D-E)*(F+G)").c_str(), "AB+C*DE-FG+*-");
  cout << infix2postfix("(A+B)*C-(D-E)*(F+G)").c_str() << endl;
}

